
    <?php 
        require 'view/header.php'; 
        require 'view/menu.php';
    ?>

    <div id="main" class="container col-12 col-md-8 col-lg-6 col-xl-5">
        <h1>Seccion de detalles del usuario</h1>

        <div class="center"><?php echo $this->mensaje; ?></div>
        <form  class="form-control" action="<?php echo constant('URL'); ?>users/actualizarUsuario" method="post">
            <p>
                <label for="nombreusuario">Nombre Usuario</label><br>
                <input class="form-control" type="text" name="UserName" id="UserName" value="<?php echo $this->usuario->UserName; ?>" required>                              
                <input type="hidden" name="IdUser" id="IdUser" value="<?php echo $this->usuario->IdUser; ?>" required>                              
            </p>
            <p>
                <label for="nombre">Nombre</label><br>
                <input class="form-control" type="text" name="FirtsName" id="FirtsName" value="<?php echo $this->usuario->FirtsName; ?>" required>               
            </p>
            <p>
                <label for="apellidos">Apellidos</label><br>
                <input class="form-control" type="text" name="LastName" id="LastName" value="<?php echo $this->usuario->LastName; ?>" required>
            </p>
            <p>
                <label for="email">Email</label><br>
                <input class="form-control" type="email" name="Email" id="Email" value="<?php echo $this->usuario->Email; ?>" required>
            </p>    
            <p>
                <button type="submit" class="btn btn-primary">Enviar</button>
            </p>        
        </form>
    </div>

    <?php require 'view/footer.php';?>
