<?php
  require 'view/header.php';  
  require 'view/menu.php';
?>
<h1>Registro de usuarios</h1>
<table class="table">
    <thead>
        <tr>
            <th></th>
            <th></th>
            <th></th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td scope="row"></td>
            <td></td>
            <td></td>
        </tr>
        <tr>
            <td scope="row"></td>
            <td></td>
            <td></td>
        </tr>
    </tbody>
</table>



<?php
  require 'view/footer.php';
?>