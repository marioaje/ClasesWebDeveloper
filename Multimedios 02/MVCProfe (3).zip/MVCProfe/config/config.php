<?php
    define('HOST','localhost');
    define('DB','mvc');
    define('USER','root');
    define('PASSWORD','');
    define('CHARSET','utf8mb4');

    define('URL','http://localhost/academia40/Multimedios%2002/MVCProfe/');
?>