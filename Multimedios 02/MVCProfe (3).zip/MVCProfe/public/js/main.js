const botones =  document.querySelectorAll(".btneliminarusuario");
const botoneseliminarcondominio =  document.querySelectorAll(".btneliminarcondominio");
const botoneseliminarcarro =  document.querySelectorAll(".btneliminarcarro");
const botoneseliminarpersona =  document.querySelectorAll(".btneliminarpersona");
const botoneseliminaringresosalidas =  document.querySelectorAll(".btneliminaringresosalidas");
const botoneseliminarpuesto =  document.querySelectorAll(".btneliminarpuesto");

const urlprincipal = "http://localhost/academia40/Multimedios%2002/MVCProfe/";
//const urlprincipal = "https://paginas-web-cr.com/condominio/";

//Btn eliminar usuario
botones.forEach(boton =>{
    boton.addEventListener("click", function(){        
        const idusuario = this.dataset.idusuario;
        
        const confirm = window.confirm("Desea elimnar el registro " + idusuario + "?");

        if (confirm){
            httpRequest(urlprincipal+"consulta/eliminarUsuario/"+idusuario, function(){
                //console.log(this.responseText);
                document.querySelector("#respuesta").innerHTML = this.responseText;

                const tbody = document.querySelector("#myTable");
                const fila = document.querySelector("#fila-"+idusuario);
                
                tbody.removeChild(fila);
            });
        }
    });
});

//Btn elimnar condominio
botoneseliminarcondominio.forEach(boton =>{
    boton.addEventListener("click", function(){        
        const idcondominio = this.dataset.idcondominio;
        
        const confirm = window.confirm("Desea elimnar el registro " + idcondominio + "?");

        if (confirm){
            httpRequest(urlprincipal+"consultacondominio/eliminarcondominio/"+idcondominio, function(){
                //console.log(this.responseText);
                document.querySelector("#respuesta").innerHTML = this.responseText;

                const tbody = document.querySelector("#myTable");
                const fila = document.querySelector("#fila-"+idcondominio);
                
                tbody.removeChild(fila);
            });
        }
    });
});

//Btn elimnar carro
botoneseliminarcarro.forEach(boton =>{
    boton.addEventListener("click", function(){        
        const idcarro = this.dataset.idcarro;
      //  $("#miModal").modal("show");
        const confirm = window.confirm("Desea elimnar el registro " + idcarro + "?");

        if (confirm){
            httpRequest(urlprincipal+"consultacarro/eliminarcarro/"+idcarro, function(){
                //console.log(this.responseText);
                document.querySelector("#respuesta").innerHTML = this.responseText;

                const tbody = document.querySelector("#myTable");
                const fila = document.querySelector("#fila-"+idcarro);
                
                tbody.removeChild(fila);
            });
        }
    });
});

//Btn elimnar persona
botoneseliminarpersona.forEach(boton =>{
    boton.addEventListener("click", function(){        
        const idpersona = this.dataset.idpersona;
        
        const confirm = window.confirm("Desea elimnar el registro " + idpersona + "?");

        if (confirm){
            httpRequest(urlprincipal+"consultapersona/eliminarpersona/"+idpersona, function(){
                //console.log(this.responseText);
                document.querySelector("#respuesta").innerHTML = this.responseText;

                const tbody = document.querySelector("#myTable");
                const fila = document.querySelector("#fila-"+idpersona);
                
                tbody.removeChild(fila);
            });
        }
    });
});

//Btn elimnar persona
botoneseliminaringresosalidas.forEach(boton =>{
    boton.addEventListener("click", function(){        
        const idingresosalidas = this.dataset.idingresosalidas;
        
        const confirm = window.confirm("Desea elimnar el registro " + idingresosalidas + "?");

        if (confirm){
            httpRequest(urlprincipal+"consultaingresosalidas/eliminaringresosalida/"+idingresosalidas, function(){
                //console.log(this.responseText);
                document.querySelector("#respuesta").innerHTML = this.responseText;

                const tbody = document.querySelector("#myTable");
                const fila = document.querySelector("#fila-"+idingresosalidas);
                
                tbody.removeChild(fila);
            });
        }
    });
});


//Btn elimnar puesto
botoneseliminarpuesto.forEach(boton =>{
    boton.addEventListener("click", function(){        
        const idpuesto = this.dataset.idpuesto;
        
        const confirm = window.confirm("Desea elimnar el registro " + idpuesto + "?");

        if (confirm){
            httpRequest(urlprincipal+"consultapuestos/eliminarpuesto/"+idpuesto, function(){
                //console.log(this.responseText);
                document.querySelector("#respuesta").innerHTML = this.responseText;

                const tbody = document.querySelector("#myTable");
                const fila = document.querySelector("#fila-"+idpuesto);
                
                tbody.removeChild(fila);
            });
        }
    });
});

function httpRequest(url, callback){
    const http = new XMLHttpRequest();
    http.open("GET", url);
    http.send();

    http.onreadystatechange = function(){
        if(this.readyState == 4 && this.status == 200){
            callback.apply(http);
        }
    }
}


//Search in the table
$(document).ready(function(){
    $("#myInput").on("keyup", function() {
        var value = $(this).val().toLowerCase();
        $("#myTable tr").filter(function() {
        $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
        });
    });
});