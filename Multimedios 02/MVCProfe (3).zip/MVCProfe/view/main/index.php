<?php
  require 'view/header.php';  
  require 'view/menu.php';
?>
<div id="main" class="container">
  <h1>Main</h1>
</div>
<?php
  require 'view/footer.php';
?>