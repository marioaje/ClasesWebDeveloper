<label for="" class="form-label">Rol</label>
      <select name="IdRol" id="IdRol">
        <option value="0">Admin</option>
        <option value="1">User</option>
</select>