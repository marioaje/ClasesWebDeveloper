<?php
    class Carro{
        public $IdCarro;
        public $IdCedula;
        public $Marca;
        public $Modelo;
        public $Anho;
        public $Nombre;
        public $PrimerApellido;
        public $SegundoApellido;
        public $Placa;
    }
?>