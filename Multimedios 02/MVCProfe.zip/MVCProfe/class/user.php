<?php

    class User{
       public $IdUser;

       public $IdPersonal;
        
       public $FirtsName;
        
       public $LastName;
        
       public $Email;
        
        public $UserName;
        
        public $Password;
        
        public $IdRol;
        
        public $CreatedAt;
        
        public $UpdatedAt;
        
        public $Enabled;
    }

?>