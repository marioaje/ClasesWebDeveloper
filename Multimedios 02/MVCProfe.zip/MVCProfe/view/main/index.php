<?php
  require 'view/header.php';  
  require 'view/menu.php';
?>
<h1>Main</h1>
<?php
  require 'view/footer.php';
?>