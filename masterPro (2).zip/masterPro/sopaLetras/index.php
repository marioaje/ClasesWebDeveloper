

<?php

$sopa = ['M', 'F', 'G','H','K','I','R', 'V', 'S', 'G'];
$sopa2 = ['A', 'W', 'A', 'L', 'A', 'p', 'L', 'A', 'p'];
$sopa3 = ['A', 'M', 'A', 'L', 'A', 'p', 'L', 'A', 'p'];

$matriz = [ $sopa, $sopa2 , $sopa3 ];

var_dump($matriz);


$recibePalabra = "MONO";

buscarPablabra ($recibePalabra, $matriz);


function buscarPablabraHorizontal ( $recibePalabra, $matriz){

    foreach ($matriz as $key => $value) {    
        # code...
        //1-recorrer, por fila, 
        //2-Busque la primera letra $recibePalabra => ['a','l','a'],
        foreach ($recibePalabraArreglo as $key => $value) {
            # code...
                    //if  ( [i] =$key => $value  )
                        if (empty (incial))
                            //incial = $key
                            //a

                            //['a','l','a'].length  
                            if (['a','l','a'].length == 3 ) 
                               // final    
                  //else if  ( [i] =$key => $value  )
                     //incial = ""

                    
        }
    }


    function buscarPablabravertical( $recibePalabra, $matriz){{
        foreach ($matrizas $key => $value) {
            for 
            # code...
        }
    }

}





?>
