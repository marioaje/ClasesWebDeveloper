<?php
    function connect(){
        $host = 'localhost';
        $db_name = 'masterpro';
        $username = 'root';
        $password = '';
        $charset = "utf8mb4";
        try {
            $connection = "mysql:host=".$host.";dbname=".$db_name.";charset=".$charset;
            $option = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_EMULATE_PREPARES => false,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
            ];

            $pdo = new PDO( $connection, $username, $password, $option );

            return $pdo;
      
        } catch (PDOException $th) {
            echo "Failed connection: ".$th->getMessage();
        }
    }
?>