<?php
  require 'header.php';  
  require 'menu.php';
?>
<div id="main" class="container">
  <h1>Main</h1>
</div>
<?php
  require 'footer.php';
?>