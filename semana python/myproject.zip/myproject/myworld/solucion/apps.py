from django.apps import AppConfig


class SolucionConfig(AppConfig):
    name = 'solucion'
