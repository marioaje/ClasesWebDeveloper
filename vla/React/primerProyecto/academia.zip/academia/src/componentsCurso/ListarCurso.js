//imr
import React from 'react';
//ccc

class ListarCurso extends React.Component {
    constructor(props) {
        super(props);
        this.state = {  
            datosCargados:false,
            datosCursos:[]
        }
    }

    cargarDatos(){
        fetch("https://paginas-web-cr.com/ApiPHP/apis/ListaCurso.php")//solicitamos la url
        .then(repuesta=>repuesta.json())
        .then((datosRepuesta) =>
            {
                this.setState({ datosCargados: true, datosCursos:datosRepuesta.data })
                console.log(datosRepuesta.data)
            })
        .catch(console.log)
    }

    funcionEliminar=(id)=>{
        alert('eliminando datos:'+id);
        //crear la funcion de fecth
    }

    funcionActualizar=(objeto)=>{
        console.log('objeto',objeto);
        //modal y cargar los datos en los inputs del modal
        //luego de cargar los datos crear una funcion de actualizar datos
    }

    componentDidMount(){
        this.cargarDatos();
    }

    render() { 
//Carga los datos en el render
        const{datosCargados, datosCursos}=this.state

        return ( 
            <div className='container'>
                <div className="table-responsive-xxl">
                    <table className="table table-primary">
                        <thead>
                            <tr>
                                <th scope="col">Id</th>
                                <th scope="col">Nombre</th>
                                <th scope="col">Descripcion</th>
                                <th scope="col">Tiempo</th>
                                <th scope="col">Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                datosCursos.map(
                                    (datosCursoExtraidos)=>(
                                        <tr key={datosCursoExtraidos.id}>    
                                            <td>{datosCursoExtraidos.id}</td>
                                            <td>{datosCursoExtraidos.nombre}</td>
                                            <td>{datosCursoExtraidos.descripcion}</td>
                                            <td>{datosCursoExtraidos.tiempo}</td>
                                            <td>
                                                <div class="btn-group" role="group" aria-label="Basic example">
                                                    <button type="button" class="btn btn-warning" onClick={() => this.funcionActualizar(datosCursoExtraidos)}>Editar</button>
                                                    <button type="button" class="btn btn-danger" onClick={() => this.funcionEliminar(datosCursoExtraidos.id)}>Borrar</button>
                                                </div>
                                            </td>
                                        </tr> 
                                    )
                                )
                            }
                        
                        </tbody>
                    </table>
                </div>
                
            </div>

         );
    }
}
 
export default ListarCurso;

// Compiled with problems:X

// ERROR

// [eslint] 
// src\componentsCurso\ListarCurso.js
//   Line 6:27:  'Component' is not defined  no-undef

// Search for the keywords to learn more about each error.