import React from 'react';

class Dashboard extends React.Component {
    constructor(props) {
        super(props);
    }
    state = {  }
    render() { 
        return ( 
            <div class="container">
                Dashboard
            </div>

         );
    }
}
 
export default Dashboard;